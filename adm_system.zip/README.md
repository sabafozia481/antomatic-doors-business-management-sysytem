# Automatic Doors Business Management System (ADM System)

A professional, full-stack web application designed for Automatic Door businesses to manage clients, projects, income, and expenses.

## Features
- **Secure Authentication**: RBAC (Admin, Manager, Staff).
- **Dashboard**: Real-time business summary.
- **Client Management**: Track client details and contact info.
- **Project Tracking**: Manage status, costs, and assignments.
- **Financial Management**: Track every penny with Income and Expense logs.
- **Reporting**: Export table data to CSV.
- **Responsive Design**: Works perfectly on mobile, tablets, and desktops.

## Tech Stack
- **Backend**: PHP 7.4+ (Modular & Secure).
- **Database**: MySQL.
- **Frontend**: HTML5, CSS3 (Modern SaaS Style), Vanilla JavaScript.
- **Security**: PDO Prepared Statements, Password Hashing, Input Sanitization.

---

## Installation Instructions

### 1. Database Setup
1. Open your database management tool (like phpMyAdmin).
2. Create a new database named `automatic_doors_db`.
3. Import the `database.sql` file provided in the root directory.

### 2. Configuration
1. Open `config/db.php`.
2. Update the following constants with your database credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'your_username');
   define('DB_PASS', 'your_password');
   define('DB_NAME', 'automatic_doors_db');
   ```

### 3. Upload to Server
1. Upload all files and folders to your web server (public_html directory).
2. Ensure PHP is enabled on your server.

### 4. Admin Login
- **URL**: `http://your-domain.com/login.php`
- **Email**: `admin@example.com`
- **Password**: `admin123`

---

## Security Notes
- Change the default Admin password immediately after logging in.
- For production, ensure `display_errors` is turned off in your PHP configuration.
- Use HTTPS for secure session handling.

## License
MIT License
